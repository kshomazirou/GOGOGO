package fillstruct

type B struct {
	ExportedInt   int
	unexportedInt int
}
